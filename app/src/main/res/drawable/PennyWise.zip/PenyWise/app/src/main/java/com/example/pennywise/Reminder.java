package com.example.pennywise;

import android.app.Activity;

public class Reminder extends Activity {
}
